#!/bin/csh -f
# usage ./run.sh number_of_strands total_nodes current_node data_directory

# specify master level directory
set mdir = 
set ndir = Data

# number of strands
set nstrand=$1
set nodes=$2
set number=$3
set odir=$4

# specify the directory to store data
set dir = $mdir/$ndir/$odir

@ int = $nstrand / $nodes
@ fin = $int * $number
@ beg = $number - 1

@ c = $beg * $int
@ x = $fin - 1

# create all the directories and copy the loop.in file to them
set i = $c
while ($i <= $x);
    set counter=`printf %04d $i`
    mkdir -p $ndir/$odir/loop$counter
	  cd $dir/loop$counter
    cp $mdir/loop.in .
    cd $mdir
    @ i++
end

# loop through the simulations from start to nstrand and move the files
# to the data directory after each run.
set i=$c
while ($i <= $x);
    set counter=`printf %04d $i`
    set l = $i
    @ l++
    echo "Starting sim number: $l of $fin"
    ./loop $i
	  cd $dir/loop$counter
    mv $mdir/burst_inform"$counter".dat .
    mv $mdir/control"$counter".dat .
    mv $mdir/en"$counter".dat .
    mv $mdir/enrhove"$counter".dat .
    mv $mdir/loop"$counter".dat .
    sleep 3
		mv $mdir/save"$counter".dat .
		cd $mdir
		echo "Finished sim number: $l of $fin"
		 
		@ i++
end
    # clean up the save$counter.dat files
#    cd $dir/loop$counter
#    mv $mdir/save"$counter".dat .
#		cd mdir
#		echo $i
#    @ i++
#		echo $i
#end