#!/bin/csh -f
# usage ./tidy_up

rm *.dat
rm loop

