#!/bin/csh -f
# usage ./compile.sh

# define master directory
set mdir = 

rm loop
cd $mdir/src
make clean
make
sleep 1
cp lare . $mdir
make clean
cd ..
mv lare "loop"
echo "Compile Script Exited"
